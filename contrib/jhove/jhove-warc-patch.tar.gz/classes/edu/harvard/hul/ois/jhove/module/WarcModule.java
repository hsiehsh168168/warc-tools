/**********************************************************************
 * Jhove - JSTOR/Harvard Object Validation Environment
 * Copyright 2004-2007 by JSTOR and the President and Fellows of Harvard College
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at
 * your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 * USA
 **********************************************************************/

package edu.harvard.hul.ois.jhove.module;


import edu.harvard.hul.ois.jhove.module.warc.wfile;
import edu.harvard.hul.ois.jhove.module.warc.wrecord;
import java.io.*;
//import java.util.*;
import edu.harvard.hul.ois.jhove.*;
//import edu.harvard.hul.ois.jhove.module.html.*;

/**
 *  Module for identification and validation of HTML files.
 * 
 *  HTML is different from most of the other documents in that
 *  sloppy construction is practically assumed in the specification.
 *  This module attempt to report as many errors as possible and
 *  recover reasonably from errors. To do this, there is more
 *  heuristic behavior built into this module than into the more
 *  straightforward ones.
 * 
 *  XHTML is recognized by this module, but is handed off to the
 *  XML module for processing.  If the XML module is missing (which
 *  it shouldn't be if you've installed the JHOVE application without
 *  modifications), this won't be able to deal with XHTML files.
 * 
 *  HTML should be placed ahead of XML in the module order.  If the
 *  XML module sees an XHTML file first, it will recognize it as XHTML,
 *  but won't be able to report the complete properties.
 * 
 *  The HTML module uses code created with the JavaCC parser generator
 *  and lexical analyzer generator.  There is apparently a bug in
 *  JavaCC which causes blank lines not to be counted in certain cases,
 *  causing lexical errors to be reported with incorrect line numbers.
 *
 * @author Gary McGath
 *
 */
public class WarcModule extends ModuleBase {

    /******************************************************************
     * PRIVATE CLASS FIELDS.
     ******************************************************************/

    private static final String NAME = "WARC-ineodev";
    private static final String RELEASE = "1.6";
    private static final int [] DATE = {2008, 11, 13};
    private static final String [] FORMAT = {
        "WARC"
    };
    private static final String COVERAGE = "WARC";

    private static final String [] MIMETYPE = {
        "text/warc"
    };
    private static final String WELLFORMED = "";
    private static final String VALIDITY = "";
    private static final String REPINFO = "";
    private static final String NOTE = "";
    private static final String RIGHTS = "Copyright INEODEV"; 

    /******************************************************************
     * PRIVATE INSTANCE FIELDS.
     ******************************************************************/

    

    /******************************************************************
    * CLASS CONSTRUCTOR.
    ******************************************************************/

    public WarcModule ()
    {
       super (NAME, RELEASE, DATE, FORMAT, COVERAGE, MIMETYPE, WELLFORMED,
              VALIDITY, REPINFO, NOTE, RIGHTS, false);

       Agent agent = new Agent ("INEODEV",
                                AgentType.EDUCATIONAL);
       agent.setAddress ("Client address");
       agent.setTelephone ("TEL number");
       agent.setEmail("jhove-support@hulmail.harvard.edu");
       _vendor = agent;


       Signature sig = new ExternalSignature (".warc", SignatureType.EXTENSION,
                                    SignatureUseType.OPTIONAL);
       _signature.add (sig);
    }


    public int parse (InputStream stream, RepInfo info, int parseIndex)
       throws IOException
    {
        System.out.println("WARC VALIDATION TEST");

            wfile a = new wfile(_je. getFn(), 600 * 1024 * 1024, 1, 0, ".");
 

			
			if (a.isValid(a.file) == 0)  info.setWellFormed (true); 
			
			else {info.setWellFormed (false); System.out.println("THE FILE IS INVALID");}
			
    	    
    	        	            
        

        return 0;
    }
    

    public void checkSignatures (File file,
                InputStream stream, 
                RepInfo info) 
        throws IOException
    {	
    	info.setWellFormed (false);

    	return;
        
    }
    
    
    

}
